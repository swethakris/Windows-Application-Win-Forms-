﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class PersonInfo : Form
    {
        Person personObj;
        List<Person> lstPerson = new List<Person>();
        DataTable dt;

        public PersonInfo()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button4.Visible = false;
            dataGridView1.DataSource = lstPerson;
            dataGridView1.Visible = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var obj = lstPerson.FirstOrDefault(x => x.getFirstName() == textBox1.Text);

            if (validate() && obj == null)
            {
                personObj = new Person(textBox1.Text, textBox2.Text, Convert.ToString(comboBox1.SelectedItem), (DateTime)dateTimePicker1.Value);

                lstPerson.Add(personObj);

                MessageBox.Show("Details are submitted");
            }         
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var obj = lstPerson.FirstOrDefault(x => x.getFirstName() == textBox1.Text);

            if (obj != null && validate())
            {
                obj.setFirstName(textBox1.Text);
                obj.setLastName(textBox2.Text);
                obj.setGender(Convert.ToString(comboBox1.SelectedItem));
                obj.setDOB(dateTimePicker1.Value);

                MessageBox.Show("Record updated");
            }
            else
            {
                MessageBox.Show("Please enter existing first name");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var obj = lstPerson.FirstOrDefault(x => x.getFirstName() == textBox1.Text);

            if (obj != null)
            {
                lstPerson.Remove(obj);

                MessageBox.Show("Record deleted");
            }
            else
            {
                MessageBox.Show("Please enter existing first name");
            }
        }

        private bool validate()
        {
            if (textBox1.Text == "")
            {
                label6.Text = "Please enter valid First Name";
                return false;
            }
            else
                label6.Text = "";

            if (textBox2.Text == "")
            {
                label7.Text = "Please enter valid Last Name";
                return false;
            }
            else
                label7.Text = "";


            if (comboBox1.SelectedIndex == -1)
            {
                label9.Text = "Please select gender";
                return false;
            }
            else
                label9.Text = "";

            return true;
        }

        private void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            var list = new BindingList<Person>(lstPerson);
            dataGridView1.DataSource = list;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            button5.Visible = false;
            button4.Visible = true;


            dt = new DataTable();

            dt.Columns.Add(new DataColumn("First Name", typeof(string)));

            dt.Columns.Add(new DataColumn("Last Name", typeof(string)));

            dt.Columns.Add(new DataColumn("Date of Birth", typeof(DateTime)));

            dt.Columns.Add(new DataColumn("Gender", typeof(string)));

            foreach (var l_str in lstPerson)
            {
                DataRow dr = dt.NewRow();

                dr["First Name"] = l_str.getFirstName() ;

                dr["Last Name"] = l_str.getLastName();

                dr["Date of Birth"] = l_str.getDOB() ;

                dr["Gender"] = l_str.getGender() ; 

                dt.Rows.Add(dr);

                dt.AcceptChanges();
            }

            dataGridView1.DataSource = dt;
            dataGridView1.RowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            panel1.Visible = true;
            button4.Visible = false;
            button5.Visible = true;

            textBox1.Text = "";
            textBox2.Text = "";
            dateTimePicker1.Value = DateTime.Now;
            comboBox1.SelectedIndex = -1;
        }


    }
}
