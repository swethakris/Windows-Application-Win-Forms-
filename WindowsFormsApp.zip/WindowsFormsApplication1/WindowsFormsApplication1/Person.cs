﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Person
    {

        private string firstName;
        private string lastName;
        private DateTime dateOfBirth;
        private string gender;

        public Person()
        {
        }

        public Person(string firstName, string lastName, string gender, DateTime dob)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.gender = gender;
            this.dateOfBirth = dob;
        }


        public string getFirstName()
        {
            return this.firstName;
        }

        public void setFirstName(string firstName)
        {
            this.firstName = firstName;
        }

        public string getLastName()
        {
            return this.lastName;
        }

        public void setLastName(string lastName)
        {
            this.lastName = lastName;
        }

        public string getGender()
        {
            return this.gender;
        }

        public void setGender(string gender)
        {
            this.gender = gender;
        }

        public DateTime getDOB()
        {
            return this.dateOfBirth;
        }

        public void setDOB(DateTime dob)
        {
            this.dateOfBirth = dob;
        }
    }
}
